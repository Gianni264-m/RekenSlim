const euro = n => new Intl.NumberFormat('nl-BE',{style:'currency',currency:'EUR'}).format(n);
const num = id => Number(document.getElementById(id).value);
const out = (id, html) => document.getElementById(id).innerHTML = html;

function calcBTW(){
  const amount=num('btwAmount'), rate=num('btwRate')/100, mode=document.getElementById('btwMode').value;
  if(amount<0)return;
  if(mode==='excl'){const tax=amount*rate;out('btwResult',`Excl. BTW: <strong>${euro(amount)}</strong><br>BTW: <strong>${euro(tax)}</strong><br>Incl. BTW: <strong>${euro(amount+tax)}</strong>`)}
  else{const excl=amount/(1+rate);out('btwResult',`Incl. BTW: <strong>${euro(amount)}</strong><br>Excl. BTW: <strong>${euro(excl)}</strong><br>BTW: <strong>${euro(amount-excl)}</strong>`)}
}
function calcDiscount(){const p=num('discountPrice'),d=num('discountPct');const save=p*d/100;out('discountResult',`Je bespaart <strong>${euro(save)}</strong>.<br>Nieuwe prijs: <strong>${euro(p-save)}</strong>.`)}
function calcPct(){const p=num('pct'),a=num('pctAmount');out('pctResult',`<strong>${p}% van ${euro(a)} = ${euro(a*p/100)}</strong>`)}
function calcAge(){
  const b=new Date(document.getElementById('birth').value+'T00:00:00'), at=new Date(document.getElementById('ageAt').value+'T00:00:00');
  if(isNaN(b)||isNaN(at)||at<b){out('ageResult','Kies geldige datums.');return}
  let y=at.getFullYear()-b.getFullYear(), m=at.getMonth()-b.getMonth(), d=at.getDate()-b.getDate();
  if(d<0){m--;d+=new Date(at.getFullYear(),at.getMonth(),0).getDate()} if(m<0){y--;m+=12}
  out('ageResult',`Leeftijd: <strong>${y} jaar, ${m} maanden en ${d} dagen</strong>.`);
}
function calcDates(){
  const a=new Date(document.getElementById('dateStart').value+'T00:00:00'),b=new Date(document.getElementById('dateEnd').value+'T00:00:00');
  const days=Math.round((b-a)/86400000);out('dateResult',days>=0?`Verschil: <strong>${days.toLocaleString('nl-BE')} dagen</strong>.`:'De einddatum moet na de startdatum liggen.');
}
function calcSalary(){const h=num('hourly'),w=num('hours'),weekly=h*w,monthly=weekly*52/12;out('salaryResult',`Geschat bruto per week: <strong>${euro(weekly)}</strong><br>Geschat bruto per maand: <strong>${euro(monthly)}</strong><br><small>Op basis van 52 weken / 12 maanden.</small>`)}
function calcKm(){const d=num('kmDistance'),r=num('kmRate');out('kmResult',`Geschatte vergoeding: <strong>${euro(d*r)}</strong>`)}
function todayLocal(){const d=new Date();return new Date(d.getFullYear(),d.getMonth(),d.getDate()).toISOString().slice(0,10)}
document.getElementById('birth').value='1995-01-01';document.getElementById('ageAt').value=todayLocal();
document.getElementById('dateStart').value=todayLocal();const tomorrow=new Date();tomorrow.setDate(tomorrow.getDate()+30);document.getElementById('dateEnd').value=tomorrow.toISOString().slice(0,10);
calcBTW();calcDiscount();calcPct();calcAge();calcDates();calcSalary();calcKm();
document.getElementById('search').addEventListener('input',e=>{const q=e.target.value.toLowerCase();document.querySelectorAll('.calc-card').forEach(c=>c.style.display=c.dataset.title.includes(q)?'':'none')});
